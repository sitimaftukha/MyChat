package com.siti.groupchatsiti.model

class GroupTypingModel(var userEmail: String?,var name: String?, var typing: String?)
