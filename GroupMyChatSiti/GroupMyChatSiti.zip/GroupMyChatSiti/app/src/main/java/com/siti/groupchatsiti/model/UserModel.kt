package com.siti.groupchatsiti.model

class UserModel(var name: String?, var email: String?) {
    var isSelected: Boolean = false
}
