package com.siti.groupchatsiti.model

import java.io.Serializable

class GroupUserModel(var email: String?, var name: String?, var adminTxt: String?, var userActive: String?) : Serializable


