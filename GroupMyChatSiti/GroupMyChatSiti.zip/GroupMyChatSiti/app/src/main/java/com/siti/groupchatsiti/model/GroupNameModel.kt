package com.siti.groupchatsiti.model

class GroupNameModel(var groupName: String?)
